package org.example.jfxboilerplate.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import org.example.jfxboilerplate.App;
import org.example.jfxboilerplate.common.AppConstants;

public class MainController extends BaseController {
    @FXML
    private Label welcomeText;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }

    @FXML
    protected void loadHome() {
        loadModule("home");
    }

    @FXML
    protected void loadPage2() {
        loadModule("page2");
    }

    @FXML
    protected void loadPage3() {
        loadModule("page3");
    }
    @FXML
    protected void loadBorrowersCheck() {loadModule("BorrowersCheck");}
    @FXML
    private void loadLoanForm() {loadModule("LoanForm");}
    @FXML
    private Label usernameLabel;

    public static String loggedInUserFullName;

    @FXML
    private void handleLogout() {
        App.loadScene("LoginPage", AppConstants.WINDOW_WIDTH, AppConstants.WINDOW_HEIGHT);
    }



    @Override
    public void initialize() {
        super.initialize();
        loadModule("home");

        if (usernameLabel != null && loggedInUserFullName != null) {
            usernameLabel.setText("👤 " + loggedInUserFullName);
        }
    }
}