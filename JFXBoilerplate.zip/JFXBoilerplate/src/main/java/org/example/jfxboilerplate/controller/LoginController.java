package org.example.jfxboilerplate.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.example.jfxboilerplate.App;
import org.example.jfxboilerplate.common.AppConstants;
import org.example.jfxboilerplate.common.Utils;
import org.example.jfxboilerplate.util.DatabaseUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;

    @FXML
    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Σφάλμα", "Συμπληρώστε όλα τα πεδία.");
            return;
        }

        String sql = "SELECT * FROM staff_accounts WHERE username = ?";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String storedHash = rs.getString("password");

                if (Utils.verifyHash(password, storedHash)) {
                    MainController.loggedInUserFullName = rs.getString("full_name");
                    App.loadScene("main", AppConstants.WINDOW_WIDTH, AppConstants.WINDOW_HEIGHT);
                } else {
                    showAlert(Alert.AlertType.ERROR, "Αποτυχία Σύνδεσης", "Λανθασμένος κωδικός.");
                }
            } else {
                showAlert(Alert.AlertType.ERROR, "Αποτυχία Σύνδεσης", "Ο χρήστης δεν βρέθηκε.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Σφάλμα", "Αποτυχία σύνδεσης με βάση.");
        }
    }

    @FXML
    private void handleCreateAccount() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Staff Key Required");
        dialog.setHeaderText("Εισάγετε το Staff Key για δημιουργία λογαριασμού");
        dialog.setContentText("Staff Key:");

        dialog.showAndWait().ifPresent(input -> {
            if (input.equals("Staff2024!")) {
                App.loadScene("RegisterPage", 966, 673);
            } else {
                showAlert(Alert.AlertType.ERROR, "Λάθος Κλειδί", "Το Staff Key που δώσατε είναι λάθος.");
            }
        });
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}