package org.example.jfxboilerplate.dao;

import org.example.jfxboilerplate.model.Book;
import org.example.jfxboilerplate.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BookDao {

    public List<Book> getAllBooks() {
        List<Book> books = new ArrayList<>();
        String sql = "SELECT * FROM books";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                books.add(new Book(
                        rs.getInt("book_id"),
                        rs.getString("title"),
                        rs.getString("author"),
                        rs.getString("isbn"),
                        rs.getString("genre"),
                        rs.getInt("published_year"),
                        rs.getInt("copies_available")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return books;
    }

    public void deleteBookAndLoans(int bookId) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            try (PreparedStatement deleteLoans = conn.prepareStatement("DELETE FROM loans WHERE book_id = ?")) {
                deleteLoans.setInt(1, bookId);
                deleteLoans.executeUpdate();
            }

            try (PreparedStatement deleteBook = conn.prepareStatement("DELETE FROM books WHERE book_id = ?")) {
                deleteBook.setInt(1, bookId);
                deleteBook.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void insertBook(Book book) {
        String sql = "INSERT INTO books (title, author, isbn, genre, published_year, copies_available) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, book.getTitle());
            stmt.setString(2, book.getAuthor());
            stmt.setString(3, book.getIsbn());
            stmt.setString(4, book.getGenre());
            stmt.setInt(5, book.getPublishedYear());
            stmt.setInt(6, book.getCopiesAvailable());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public List<String> getAllGenres() {
        List<String> genres = new ArrayList<>();
        String sql = "SELECT DISTINCT genre FROM books";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                genres.add(rs.getString("genre"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return genres;
    }

    public void updateBook(Book book) {
        String sql = "UPDATE books SET title=?, author=?, isbn=?, genre=?, published_year=?, copies_available=? WHERE book_id=?";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, book.getTitle());
            stmt.setString(2, book.getAuthor());
            stmt.setString(3, book.getIsbn());
            stmt.setString(4, book.getGenre());
            stmt.setInt(5, book.getPublishedYear());
            stmt.setInt(6, book.getCopiesAvailable());
            stmt.setInt(7, book.getBookId());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
