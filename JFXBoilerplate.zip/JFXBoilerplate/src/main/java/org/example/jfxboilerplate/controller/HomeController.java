package org.example.jfxboilerplate.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import org.example.jfxboilerplate.dao.BookDao;
import org.example.jfxboilerplate.model.Book;
import org.example.jfxboilerplate.services.BookApiService;

import java.util.List;
import java.util.Map;

public class HomeController extends BaseController {

    @FXML private TableView<Book> booksTable;
    @FXML private TableColumn<Book, Integer> colBookId;
    @FXML private TableColumn<Book, String> colTitle;
    @FXML private TableColumn<Book, String> colAuthor;
    @FXML private TableColumn<Book, String> colIsbn;
    @FXML private TableColumn<Book, String> colGenre;
    @FXML private TableColumn<Book, Integer> colPublishedYear;
    @FXML private TableColumn<Book, Integer> colCopiesAvailable;

    @FXML private Button toggleButton;
    @FXML private Button deleteBookButton;
    @FXML private Button editBookButton;
    @FXML private FlowPane buttonContainer;
    @FXML private TextField searchField;
    @FXML private Button addBookButton;
    @FXML private HBox actionButtons;
    @FXML private ProgressIndicator loadingIndicator;

    @FXML private VBox editForm;
    @FXML private TextField editTitleField, editAuthorField, editIsbnField, editGenreField, editYearField, editCopiesField;

    @FXML private VBox manualForm;
    @FXML private TextField titleField, authorField, isbnField, genreField, yearField, copiesField;

    private final BookDao bookDao = new BookDao();
    private Book selectedBookForEdit;

    private ObservableList<Book> bookList = FXCollections.observableArrayList();
    private ObservableList<Book> filteredBooksList = FXCollections.observableArrayList();

    @Override
    public void initialize() {
        super.initialize();
        toggleButton.setOnAction(event -> buttonContainer.setVisible(!buttonContainer.isVisible()));
        deleteBookButton.setOnAction(event -> handleDeleteBook());
        editBookButton.setOnAction(event -> handleEditBook());
        addBookButton.setOnAction(event -> handleAddBook());
        loadBooksFromDatabase();
        loadGenres();
    }

    private void loadBooksFromDatabase() {
        bookList.clear();
        bookList.addAll(bookDao.getAllBooks());

        colBookId.setCellValueFactory(new PropertyValueFactory<>("bookId"));
        colTitle.setCellValueFactory(new PropertyValueFactory<>("title"));
        colAuthor.setCellValueFactory(new PropertyValueFactory<>("author"));
        colIsbn.setCellValueFactory(new PropertyValueFactory<>("isbn"));
        colGenre.setCellValueFactory(new PropertyValueFactory<>("genre"));
        colPublishedYear.setCellValueFactory(new PropertyValueFactory<>("publishedYear"));
        colCopiesAvailable.setCellValueFactory(new PropertyValueFactory<>("copiesAvailable"));

        booksTable.setItems(bookList);
    }
    private void loadGenres() {
        buttonContainer.getChildren().clear();

        List<String> genres = bookDao.getAllGenres();

        for (String genre : genres) {
            Button genreButton = new Button(genre);
            genreButton.setStyle("-fx-font-weight: bold; -fx-background-color: transparent; -fx-border-color: #f6920b; -fx-border-radius: 10%;");
            genreButton.setTextFill(javafx.scene.paint.Color.web("#f6920b"));
            genreButton.setOnAction(event -> filterBooksByGenre(genre));
            buttonContainer.getChildren().add(genreButton);
        }
    }


    private void handleDeleteBook() {
        Book selected = booksTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING, "Καμία Επιλογή", "Παρακαλώ επιλέξτε ένα βιβλίο για διαγραφή.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Επιβεβαίωση Διαγραφής");
        confirm.setContentText("Είστε σίγουρος ότι θέλετε να διαγράψετε το βιβλίο: " + selected.getTitle() + ";");

        if (confirm.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
            bookDao.deleteBookAndLoans(selected.getBookId());
            bookList.remove(selected);
            booksTable.refresh();
            showAlert(Alert.AlertType.INFORMATION, "Επιτυχία", "Το βιβλίο διαγράφηκε.");
        }
    }

    private void showManualForm() {
        manualForm.setVisible(true);
        actionButtons.setVisible(false);
        actionButtons.setManaged(false);
    }

    @FXML
    private void handleAddBook() {
        List<String> options = List.of("Μέσω API", "Χειροκίνητα");

        ChoiceDialog<String> dialog = new ChoiceDialog<>(options.get(0), options);
        dialog.setTitle("Τρόπος Προσθήκης Βιβλίου");
        dialog.setHeaderText("Πώς θέλετε να προσθέσετε το βιβλίο;");
        dialog.setContentText("Επιλογή:");

        dialog.showAndWait().ifPresent(choice -> {
            if (choice.equals("Μέσω API")) {
                handleAddBookViaApi();
            } else {
                showManualForm();
            }
        });
    }

    private void handleAddBookViaApi() {
        TextInputDialog inputDialog = new TextInputDialog();
        inputDialog.setTitle("Αναζήτηση Βιβλίου μέσω API");
        inputDialog.setHeaderText("Εισάγετε τίτλο βιβλίου");
        inputDialog.setContentText("Τίτλος:");

        inputDialog.showAndWait().ifPresent(title -> {
            if (title.isBlank()) return;

            loadingIndicator.setVisible(true);

            Task<List<Map<String, String>>> task = new Task<>() {
                @Override
                protected List<Map<String, String>> call() {
                    return BookApiService.searchBooksByTitle(title);
                }
            };

            task.setOnSucceeded(e -> {
                loadingIndicator.setVisible(false);
                List<Map<String, String>> results = task.getValue();
                if (results.isEmpty()) {
                    showAlert(Alert.AlertType.INFORMATION, "Χωρίς Αποτελέσματα", "Δεν βρέθηκαν βιβλία για: " + title);
                    return;
                }

                List<String> displayList = results.stream()
                        .map(book -> String.format("%s — %s (%s)",
                                book.getOrDefault("title", "Άγνωστος Τίτλος"),
                                book.getOrDefault("author", "Άγνωστος Συγγραφέας"),
                                book.getOrDefault("year", "-")))
                        .toList();

                ChoiceDialog<String> dialog = new ChoiceDialog<>(displayList.get(0), displayList);
                dialog.setTitle("Επιλογή Βιβλίου");
                dialog.setHeaderText("Επιλέξτε ένα βιβλίο προς προσθήκη:");
                dialog.setContentText("Αποτελέσματα:");

                dialog.showAndWait().ifPresent(selectedString -> {
                    int index = displayList.indexOf(selectedString);
                    if (index == -1) return;

                    Map<String, String> selected = results.get(index);

                    titleField.setText(selected.getOrDefault("title", ""));
                    authorField.setText(selected.getOrDefault("author", ""));
                    yearField.setText(selected.getOrDefault("year", ""));
                    genreField.setText("");
                    isbnField.setText("");
                    copiesField.setText("1");

                    manualForm.setVisible(true);
                    actionButtons.setVisible(false);
                    actionButtons.setManaged(false);
                });
            });

            task.setOnFailed(e -> {
                loadingIndicator.setVisible(false);
                showAlert(Alert.AlertType.ERROR, "Σφάλμα", "Αποτυχία επικοινωνίας με το API.");
            });

            new Thread(task).start();
        });
    }

    @FXML
    private void handleSubmitManualBook() {
        Book book = new Book(
                0,
                titleField.getText(),
                authorField.getText(),
                isbnField.getText(),
                genreField.getText(),
                parseInt(yearField.getText()),
                parseInt(copiesField.getText())
        );

        bookDao.insertBook(book);
        showAlert(Alert.AlertType.INFORMATION, "Επιτυχία", "Το βιβλίο προστέθηκε.");
        manualForm.setVisible(false);
        actionButtons.setVisible(true);
        actionButtons.setManaged(true);
        loadBooksFromDatabase();
    }

    private int parseInt(String value) {
        try {
            return Integer.parseInt(value);
        } catch (Exception e) {
            return 0;
        }
    }
    private void filterBooksByGenre(String genre) {
        filteredBooksList.clear();
        for (Book book : bookList) {
            if (book.getGenre().equalsIgnoreCase(genre)) {
                filteredBooksList.add(book);
            }
        }
        booksTable.setItems(filteredBooksList);
    }

    private void handleEditBook() {
        selectedBookForEdit = booksTable.getSelectionModel().getSelectedItem();
        if (selectedBookForEdit == null) {
            showAlert(Alert.AlertType.WARNING, "Καμία Επιλογή", "Παρακαλώ επιλέξτε ένα βιβλίο για επεξεργασία.");
            return;
        }

        editTitleField.setText(selectedBookForEdit.getTitle());
        editAuthorField.setText(selectedBookForEdit.getAuthor());
        editIsbnField.setText(selectedBookForEdit.getIsbn());
        editGenreField.setText(selectedBookForEdit.getGenre());
        editYearField.setText(String.valueOf(selectedBookForEdit.getPublishedYear()));
        editCopiesField.setText(String.valueOf(selectedBookForEdit.getCopiesAvailable()));

        editForm.setVisible(true);
        actionButtons.setVisible(false);
        actionButtons.setManaged(false);
    }

    @FXML
    private void handleSaveEdit() {
        if (selectedBookForEdit == null) return;

        selectedBookForEdit.setTitle(editTitleField.getText());
        selectedBookForEdit.setAuthor(editAuthorField.getText());
        selectedBookForEdit.setIsbn(editIsbnField.getText());
        selectedBookForEdit.setGenre(editGenreField.getText());
        selectedBookForEdit.setPublishedYear(parseInt(editYearField.getText()));
        selectedBookForEdit.setCopiesAvailable(parseInt(editCopiesField.getText()));

        bookDao.updateBook(selectedBookForEdit);
        booksTable.refresh();
        showAlert(Alert.AlertType.INFORMATION, "Επιτυχία", "Το βιβλίο ενημερώθηκε.");
        editForm.setVisible(false);
        actionButtons.setVisible(true);
        actionButtons.setManaged(true);
        selectedBookForEdit = null;
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    @FXML
    private void handleCancelManualAdd() {
        manualForm.setVisible(false);
        actionButtons.setVisible(true);
        actionButtons.setManaged(true);
    }

    @FXML
    private void handleCancelEdit() {
        editForm.setVisible(false);
        actionButtons.setVisible(true);
        actionButtons.setManaged(true);
        selectedBookForEdit = null;
    }

    @FXML
    private void handleSearch(KeyEvent event) {
        String searchText = searchField.getText().toLowerCase();
        filteredBooksList.clear();
        for (Book book : bookList) {
            if (book.getTitle().toLowerCase().contains(searchText)) {
                filteredBooksList.add(book);
            }
        }
        booksTable.setItems(filteredBooksList);
    }
}