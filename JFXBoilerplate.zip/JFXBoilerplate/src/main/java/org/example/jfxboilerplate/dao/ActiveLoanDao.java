package org.example.jfxboilerplate.dao;

import org.example.jfxboilerplate.util.DatabaseUtil;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ActiveLoanDao {

    public static class ActiveLoan {
        public int loanId;
        public int bookId;
        public int borrowerId;
        public String borrowerName;
        public String email;
        public String phone;
        public String address;
        public String bookTitle;
        public LocalDate loanDate;
        public LocalDate dueDate;

        public ActiveLoan(int loanId, int bookId, int borrowerId, String borrowerName,
                          String email, String phone, String address,
                          String bookTitle, LocalDate loanDate, LocalDate dueDate) {
            this.loanId = loanId;
            this.bookId = bookId;
            this.borrowerId = borrowerId;
            this.borrowerName = borrowerName;
            this.email = email;
            this.phone = phone;
            this.address = address;
            this.bookTitle = bookTitle;
            this.loanDate = loanDate;
            this.dueDate = dueDate;
        }
    }

    public List<ActiveLoan> getActiveLoans() {
        List<ActiveLoan> list = new ArrayList<>();
        String sql = """
            SELECT l.loan_id, b.borrower_id, bo.book_id,
                   b.first_name, b.last_name, b.email, b.phone, b.address,
                   bo.title AS book_title,
                   l.loan_date, l.due_date
            FROM loans l
            JOIN borrowers b ON l.borrower_id = b.borrower_id
            JOIN books bo ON l.book_id = bo.book_id
            WHERE l.return_date IS NULL
            ORDER BY b.borrower_id, l.loan_date
        """;

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                list.add(new ActiveLoan(
                        rs.getInt("loan_id"),
                        rs.getInt("book_id"),
                        rs.getInt("borrower_id"),
                        rs.getString("first_name") + " " + rs.getString("last_name"),
                        rs.getString("email"),
                        rs.getString("phone"),
                        rs.getString("address"),
                        rs.getString("book_title"),
                        rs.getDate("loan_date").toLocalDate(),
                        rs.getDate("due_date").toLocalDate()
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    public void returnBook(int loanId, int bookId, int borrowerId, LocalDate dueDate) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            LocalDate today = LocalDate.now();

            try (PreparedStatement stmt = conn.prepareStatement("UPDATE loans SET return_date = ? WHERE loan_id = ?")) {
                stmt.setDate(1, Date.valueOf(today));
                stmt.setInt(2, loanId);
                stmt.executeUpdate();
            }

            try (PreparedStatement stmt = conn.prepareStatement("UPDATE books SET copies_available = copies_available + 1 WHERE book_id = ?")) {
                stmt.setInt(1, bookId);
                stmt.executeUpdate();
            }

            try (PreparedStatement stmt = conn.prepareStatement(
                    "INSERT INTO borrower_reputation (borrower_id, total_loans, late_returns) " +
                            "VALUES (?, 1, ?) " +
                            "ON DUPLICATE KEY UPDATE " +
                            "total_loans = total_loans + 1, " +
                            "late_returns = late_returns + VALUES(late_returns)")) {
                int late = today.isAfter(dueDate) ? 1 : 0;
                stmt.setInt(1, borrowerId);
                stmt.setInt(2, late);
                stmt.executeUpdate();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}