package org.example.jfxboilerplate.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import org.example.jfxboilerplate.dao.ActiveLoanDao;
import org.example.jfxboilerplate.dao.ActiveLoanDao.ActiveLoan;

import java.time.LocalDate;
import java.util.*;

public class Page3Controller {

    @FXML private VBox borrowerContainer;
    @FXML private ChoiceBox<String> filterBox;

    private final ActiveLoanDao activeLoanDao = new ActiveLoanDao();

    public void initialize() {
        filterBox.getItems().addAll("Ενεργοί Δανεισμοί (Εντός Προθεσμίας)", "Ενεργοί Δανεισμοί (Εκτός Προθεσμίας)");
        filterBox.getSelectionModel().selectFirst();
        filterBox.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            borrowerContainer.getChildren().clear();
            loadData();
        });
        loadData();
    }

    private void loadData() {
        boolean onlyOverdue = filterBox.getValue().contains("Εκτός");
        List<ActiveLoan> loans = activeLoanDao.getActiveLoans();

        Map<Integer, VBox> borrowerMap = new HashMap<>();

        for (ActiveLoan loan : loans) {
            boolean isOverdue = loan.dueDate.isBefore(LocalDate.now());

            if (onlyOverdue && !isOverdue) continue;
            if (!onlyOverdue && isOverdue) continue;

            VBox borrowerBox = borrowerMap.computeIfAbsent(loan.borrowerId, id -> {
                VBox vbox = new VBox(8);
                vbox.setStyle("-fx-padding: 10; -fx-border-color: #f6920b; -fx-border-radius: 6; -fx-background-color: #fffbe6;");
                Label info = new Label(String.format("%s | %s | %s | %s", loan.borrowerName, loan.email, loan.phone, loan.address));
                info.setStyle("-fx-font-weight: bold; -fx-font-size: 14px;");
                vbox.getChildren().add(info);
                borrowerContainer.getChildren().add(vbox);
                return vbox;
            });

            Label loanLabel = new Label(String.format("→ %s | %s ➜ %s",
                    loan.bookTitle, loan.loanDate, loan.dueDate));

            if (isOverdue) {
                loanLabel.setStyle("-fx-text-fill: red; -fx-font-weight: bold;");
            }

            Button returnBtn = new Button("Επιστροφή");
            returnBtn.setOnAction(e -> {
                activeLoanDao.returnBook(loan.loanId, loan.bookId, loan.borrowerId, loan.dueDate);
                borrowerContainer.getChildren().clear();
                loadData();
                showAlert(Alert.AlertType.INFORMATION, "Επιτυχία", "Το βιβλίο επιστράφηκε.");
            });

            HBox row = new HBox(10, loanLabel, returnBtn);
            borrowerBox.getChildren().add(row);
        }
    }

    private void showAlert(Alert.AlertType type, String title, String msg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}