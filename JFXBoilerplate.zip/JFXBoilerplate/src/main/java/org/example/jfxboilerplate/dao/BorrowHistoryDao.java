package org.example.jfxboilerplate.dao;

import org.example.jfxboilerplate.util.DatabaseUtil;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class BorrowHistoryDao {

    public static class BorrowHistoryRecord {
        public int borrowerId;
        public String firstName;
        public String lastName;
        public String email;
        public String phone;
        public String address;
        public String bookTitle;
        public LocalDate loanDate;
        public LocalDate dueDate;
        public LocalDate returnDate;
        public Double score;

        public BorrowHistoryRecord(int borrowerId, String firstName, String lastName,
                                   String email, String phone, String address,
                                   String bookTitle, LocalDate loanDate, LocalDate dueDate,
                                   LocalDate returnDate, Double score) {
            this.borrowerId = borrowerId;
            this.firstName = firstName;
            this.lastName = lastName;
            this.email = email;
            this.phone = phone;
            this.address = address;
            this.bookTitle = bookTitle;
            this.loanDate = loanDate;
            this.dueDate = dueDate;
            this.returnDate = returnDate;
            this.score = score;
        }
    }

    public List<BorrowHistoryRecord> getCompletedLoans() {
        List<BorrowHistoryRecord> list = new ArrayList<>();
        String sql = "SELECT b.borrower_id, b.first_name, b.last_name, b.email, b.phone, b.address, " +
                "bo.title AS book_title, l.loan_date, l.due_date, l.return_date, r.score " +
                "FROM loans l " +
                "JOIN borrowers b ON l.borrower_id = b.borrower_id " +
                "JOIN books bo ON l.book_id = bo.book_id " +
                "LEFT JOIN borrower_reputation r ON b.borrower_id = r.borrower_id " +
                "WHERE l.return_date IS NOT NULL " +
                "ORDER BY b.borrower_id, l.loan_date";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Double score = rs.getObject("score") != null ? rs.getDouble("score") : null;

                list.add(new BorrowHistoryRecord(
                        rs.getInt("borrower_id"),
                        rs.getString("first_name"),
                        rs.getString("last_name"),
                        rs.getString("email"),
                        rs.getString("phone"),
                        rs.getString("address"),
                        rs.getString("book_title"),
                        rs.getDate("loan_date").toLocalDate(),
                        rs.getDate("due_date").toLocalDate(),
                        rs.getDate("return_date").toLocalDate(),
                        score
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }
}