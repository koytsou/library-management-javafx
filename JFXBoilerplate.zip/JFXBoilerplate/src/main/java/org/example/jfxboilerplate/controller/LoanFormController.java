package org.example.jfxboilerplate.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.util.StringConverter;
import org.example.jfxboilerplate.dao.LoanDao;
import org.example.jfxboilerplate.dao.LoanDao.BorrowerItem;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

public class LoanFormController {

    @FXML private ComboBox<BorrowerItem> borrowerComboBox;
    @FXML private ComboBox<String> bookComboBox;
    @FXML private DatePicker loanDatePicker;
    @FXML private DatePicker dueDatePicker;

    private final LoanDao loanDao = new LoanDao();

    public void initialize() {
        loadBorrowers();
        loadBooks();
        loanDatePicker.setValue(LocalDate.now());

        loanDatePicker.setDayCellFactory(picker -> new DateCell() {
            @Override
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                if (date.isBefore(LocalDate.now())) {
                    setDisable(true);
                    setStyle("-fx-background-color: #eee;");
                }
            }
        });
    }

    private void loadBorrowers() {
        List<BorrowerItem> items = loanDao.getAllBorrowersWithScore();
        ObservableList<BorrowerItem> observableItems = FXCollections.observableArrayList(items);
        borrowerComboBox.setItems(observableItems);

        borrowerComboBox.setCellFactory(list -> new ListCell<>() {
            @Override
            protected void updateItem(BorrowerItem item, boolean empty) {
                super.updateItem(item, empty);

                if (empty || item == null) {
                    setText(null);
                    setGraphic(null);
                } else {
                    Label nameLabel = new Label(item.name);
                    nameLabel.setStyle("-fx-text-fill: black;");

                    Label scoreLabel = new Label(
                            item.score != null ? String.format("Score: %.0f%%", item.score) : "No Score"
                    );
                    scoreLabel.setStyle(item.score != null
                            ? (item.score >= 50 ? "-fx-text-fill: green;" : "-fx-text-fill: red;")
                            : "-fx-text-fill: gray;");

                    HBox content = new HBox(5, nameLabel, scoreLabel);
                    setText(null);
                    setGraphic(content);
                }
            }
        });

        borrowerComboBox.setConverter(new StringConverter<>() {
            @Override public String toString(BorrowerItem item) {
                return item == null ? "" : item.toString();
            }
            @Override public BorrowerItem fromString(String string) {
                return null;
            }
        });
    }

    private void loadBooks() {
        List<String> books = loanDao.getAvailableBooks();
        bookComboBox.getItems().setAll(books);
    }

    @FXML
    private void handleLoanSubmit() {
        if (borrowerComboBox.getValue() == null || bookComboBox.getValue() == null ||
                loanDatePicker.getValue() == null || dueDatePicker.getValue() == null) {
            showAlert(Alert.AlertType.WARNING, "Σφάλμα", "Συμπληρώστε όλα τα πεδία.");
            return;
        }

        int borrowerId = borrowerComboBox.getValue().id;
        String borrowerName = borrowerComboBox.getValue().name;
        Double scoreObj = borrowerComboBox.getValue().score;
        double score = scoreObj != null ? scoreObj : 100.0;

        int bookId = Integer.parseInt(bookComboBox.getValue().split(" - ")[0]);
        String bookTitle = bookComboBox.getValue().split(" - ", 2)[1];
        LocalDate loanDate = loanDatePicker.getValue();
        LocalDate dueDate = dueDatePicker.getValue();

        long days = ChronoUnit.DAYS.between(loanDate, dueDate);
        boolean hasActive = loanDao.hasActiveLoans(borrowerId);

        // Περιορισμοί λόγω φήμης και καθυστερήσεων
        if (score < 50 && hasActive) {
            showAlert(Alert.AlertType.ERROR,
                    "Απαγόρευση Δανεισμού",
                    "Ο χρήστης έχει χαμηλή φήμη (κάτω από 50%) και εκκρεμούν επιστροφές βιβλίων.\n" +
                            "Η ολοκλήρωση επιστροφών είναι απαραίτητη πριν από νέο δανεισμό.");
            return;
        }

        if (score < 50 && days > 7) {
            showAlert(Alert.AlertType.WARNING,
                    "Περιορισμός Διάρκειας",
                    "Ο χρήστης έχει χαμηλή φήμη (κάτω από 50%).\nΗ μέγιστη επιτρεπόμενη διάρκεια δανεισμού είναι 7 ημέρες.");

            return;
        }

        // Καταχώριση
        loanDao.submitLoan(borrowerId, bookId, loanDate, dueDate);

        showAlert(Alert.AlertType.INFORMATION, "Επιτυχία",
                "Ο δανεισμός καταχωρήθηκε:\nΔανειζόμενος: " + borrowerName +
                        "\nΒιβλίο: " + bookTitle +
                        "\nΑπό: " + loanDate + " έως: " + dueDate);

        borrowerComboBox.getSelectionModel().clearSelection();
        bookComboBox.getSelectionModel().clearSelection();
        loanDatePicker.setValue(null);
        dueDatePicker.setValue(null);
    }


    private void showAlert(Alert.AlertType type, String title, String msg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}