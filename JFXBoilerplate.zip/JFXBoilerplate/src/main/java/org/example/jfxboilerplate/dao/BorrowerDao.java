package org.example.jfxboilerplate.dao;

import org.example.jfxboilerplate.model.Borrower;
import org.example.jfxboilerplate.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BorrowerDao {

    public List<Borrower> getAllBorrowers() {
        List<Borrower> borrowers = new ArrayList<>();
        String sql = "SELECT borrower_id, first_name, last_name, email, phone, address FROM borrowers";

        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                borrowers.add(new Borrower(
                        rs.getInt("borrower_id"),
                        rs.getString("first_name"),
                        rs.getString("last_name"),
                        rs.getString("email"),
                        rs.getString("phone"),
                        rs.getString("address")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return borrowers;
    }

    public void insertBorrower(Borrower borrower) {
        String sql = "INSERT INTO borrowers (first_name, last_name, email, phone, address) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, borrower.firstNameProperty().get());
            stmt.setString(2, borrower.lastNameProperty().get());
            stmt.setString(3, borrower.emailProperty().get());
            stmt.setString(4, borrower.phoneProperty().get());
            stmt.setString(5, borrower.addressProperty().get());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateBorrower(Borrower borrower) {
        String sql = "UPDATE borrowers SET first_name=?, last_name=?, email=?, phone=?, address=? WHERE borrower_id=?";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, borrower.firstNameProperty().get());
            stmt.setString(2, borrower.lastNameProperty().get());
            stmt.setString(3, borrower.emailProperty().get());
            stmt.setString(4, borrower.phoneProperty().get());
            stmt.setString(5, borrower.addressProperty().get());
            stmt.setInt(6, borrower.borrowerIdProperty().get());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteBorrower(int borrowerId) {
        String sql = "DELETE FROM borrowers WHERE borrower_id = ?";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, borrowerId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
