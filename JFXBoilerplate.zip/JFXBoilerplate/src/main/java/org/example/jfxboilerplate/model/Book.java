// Book.java
package org.example.jfxboilerplate.model;

import javafx.beans.property.*;

public class Book {
    private final IntegerProperty bookId;
    private final StringProperty title;
    private final StringProperty author;
    private final StringProperty isbn;
    private final StringProperty genre;
    private final IntegerProperty publishedYear;
    private final IntegerProperty copiesAvailable;

    public Book(int bookId, String title, String author, String isbn, String genre, int publishedYear, int copiesAvailable) {
        this.bookId = new SimpleIntegerProperty(bookId);
        this.title = new SimpleStringProperty(title);
        this.author = new SimpleStringProperty(author);
        this.isbn = new SimpleStringProperty(isbn);
        this.genre = new SimpleStringProperty(genre);
        this.publishedYear = new SimpleIntegerProperty(publishedYear);
        this.copiesAvailable = new SimpleIntegerProperty(copiesAvailable);
    }

    public int getBookId() { return bookId.get(); }
    public void setBookId(int bookId) { this.bookId.set(bookId); }
    public IntegerProperty bookIdProperty() { return bookId; }

    public String getTitle() { return title.get(); }
    public void setTitle(String title) { this.title.set(title); }
    public StringProperty titleProperty() { return title; }

    public String getAuthor() { return author.get(); }
    public void setAuthor(String author) { this.author.set(author); }
    public StringProperty authorProperty() { return author; }

    public String getIsbn() { return isbn.get(); }
    public void setIsbn(String isbn) { this.isbn.set(isbn); }
    public StringProperty isbnProperty() { return isbn; }

    public String getGenre() { return genre.get(); }
    public void setGenre(String genre) { this.genre.set(genre); }
    public StringProperty genreProperty() { return genre; }

    public int getPublishedYear() { return publishedYear.get(); }
    public void setPublishedYear(int publishedYear) { this.publishedYear.set(publishedYear); }
    public IntegerProperty publishedYearProperty() { return publishedYear; }

    public int getCopiesAvailable() { return copiesAvailable.get(); }
    public void setCopiesAvailable(int copiesAvailable) { this.copiesAvailable.set(copiesAvailable); }
    public IntegerProperty copiesAvailableProperty() { return copiesAvailable; }
}