package org.example.jfxboilerplate.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import org.example.jfxboilerplate.dao.BorrowHistoryDao;
import org.example.jfxboilerplate.dao.BorrowHistoryDao.BorrowHistoryRecord;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;

public class BorrowersCheckController {

    @FXML private VBox borrowerContainer;
    @FXML private ChoiceBox<String> filterBox;

    private final BorrowHistoryDao borrowHistoryDao = new BorrowHistoryDao();

    public void initialize() {
        filterBox.getItems().addAll(
                "Καθυστερημένες Επιστροφές",
                "Έγκαιρες Επιστροφές",
                "Φήμη Χρηστών (Reputation)"
        );
        filterBox.getSelectionModel().selectFirst();
        filterBox.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            borrowerContainer.getChildren().clear();
            loadData();
        });
        loadData();
    }

    private void loadData() {
        String selected = filterBox.getValue();

        switch (selected) {
            case "Καθυστερημένες Επιστροφές" -> loadReturns(true);
            case "Έγκαιρες Επιστροφές" -> loadReturns(false);
            case "Φήμη Χρηστών (Reputation)" -> loadUserScores();
        }
    }

    private void loadReturns(boolean lateOnly) {
        List<BorrowHistoryRecord> records = borrowHistoryDao.getCompletedLoans();
        Map<Integer, VBox> borrowerMap = new HashMap<>();

        for (BorrowHistoryRecord record : records) {
            long diff = ChronoUnit.DAYS.between(record.dueDate, record.returnDate);
            boolean isLate = diff > 0;

            if (lateOnly && !isLate) continue;
            if (!lateOnly && isLate) continue;

            VBox borrowerBox = borrowerMap.computeIfAbsent(record.borrowerId, id -> {
                VBox vbox = new VBox(8);
                vbox.setStyle("-fx-padding: 10; -fx-border-color: #ccc; -fx-border-radius: 6; -fx-background-color: #f9f9f9;");
                Label info = new Label(String.format("%s %s | %s | %s | %s",
                        record.firstName, record.lastName, record.email, record.phone, record.address));
                info.setStyle("-fx-font-weight: bold; -fx-font-size: 14px;");
                vbox.getChildren().add(info);
                borrowerContainer.getChildren().add(vbox);
                return vbox;
            });

            Label loanLabel = new Label(String.format("→ %s | %s ➜ %s | Επιστροφή: %s | %s: %d μέρες",
                    record.bookTitle, record.loanDate, record.dueDate, record.returnDate,
                    isLate ? "Καθυστέρηση" : "Πρόωρη Επιστροφή", Math.abs(diff)));

            loanLabel.setStyle("-fx-font-size: 11px;" + (isLate ? "-fx-text-fill: red;" : "-fx-text-fill: green;"));
            borrowerBox.getChildren().add(new HBox(loanLabel));
        }
    }

    private void loadUserScores() {
        List<BorrowHistoryRecord> records = borrowHistoryDao.getCompletedLoans();
        Map<Integer, BorrowHistoryRecord> uniqueBorrowers = new LinkedHashMap<>();

        for (BorrowHistoryRecord record : records) {
            uniqueBorrowers.putIfAbsent(record.borrowerId, record);
        }

        for (BorrowHistoryRecord record : uniqueBorrowers.values()) {
            VBox box = new VBox(6);
            box.setStyle("-fx-padding: 10; -fx-border-color: #bbb; -fx-border-radius: 6; -fx-background-color: #eef;");

            String scoreText = record.score != null
                    ? String.format("Score: %.0f%%", record.score)
                    : "Χωρίς Φήμη";

            Label nameLabel = new Label(record.firstName + " " + record.lastName + " | ");
            nameLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14px;");

            Label scoreLabel = new Label(
                    record.score != null ? String.format("Score: %.0f%%", record.score) : "Χωρίς Φήμη"
            );
            scoreLabel.setStyle(record.score == null
                    ? "-fx-text-fill: gray;"
                    : record.score >= 50
                    ? "-fx-text-fill: green;"
                    : "-fx-text-fill: red;"
            );

            HBox row = new HBox(5, nameLabel, scoreLabel);
            box.getChildren().add(row);


            borrowerContainer.getChildren().add(box);
        }
    }

    private void showAlert(Alert.AlertType type, String title, String msg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}