package org.example.jfxboilerplate.services;

import org.example.jfxboilerplate.model.Book;
import org.example.jfxboilerplate.util.DatabaseUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class BookService {

    public static void insertBook(Book book) {
        String sql = "INSERT INTO books (title, author, published_year, genre) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {


            stmt.setString(1, book.getTitle());
            stmt.setString(2, book.getAuthor());
            stmt.setInt(3, book.getPublishedYear());
            stmt.setString(4, book.getGenre());

            stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    }



