package org.example.jfxboilerplate.services;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BookApiService {

    private static final ObjectMapper objectMapper = new ObjectMapper();

    public static List<Map<String, String>> searchBooksByTitle(String title) {
        List<Map<String, String>> results = new ArrayList<>();

        try {
            String query = title.replace(" ", "+");
            URL url = new URL("https://openlibrary.org/search.json?title=" + query);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            try (InputStream in = conn.getInputStream()) {
                JsonNode root = objectMapper.readTree(in);
                JsonNode docs = root.get("docs");

                if (docs != null && docs.isArray()) {
                    for (JsonNode doc : docs) {
                        Map<String, String> bookData = new HashMap<>();
                        bookData.put("title", doc.path("title").asText(""));
                        bookData.put("author", doc.path("author_name").isArray() ? doc.path("author_name").get(0).asText("") : "");
                        bookData.put("year", doc.path("first_publish_year").asText(""));
                        results.add(bookData);
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return results;
    }
}
