package org.example.jfxboilerplate.model;

import java.util.Date;

public class LoanDisplay {
    private final String borrowerName;
    private final String email;
    private final String phone;
    private final String address;
    private final String bookTitle;
    private final Date loanDate;
    private final Date dueDate;

    public LoanDisplay(String borrowerName, String email, String phone, String address,
                       String bookTitle, Date loanDate, Date dueDate) {
        this.borrowerName = borrowerName;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.bookTitle = bookTitle;
        this.loanDate = loanDate;
        this.dueDate = dueDate;
    }

    public String getBorrowerName() { return borrowerName; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public String getAddress() { return address; }
    public String getBookTitle() { return bookTitle; }
    public Date getLoanDate() { return loanDate; }
    public Date getDueDate() { return dueDate; }
}
