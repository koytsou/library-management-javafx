package org.example.jfxboilerplate.common;

public class AppConstants {
    public static final double WINDOW_WIDTH = 950;
    public static final double WINDOW_HEIGHT = 650;

    public static final String FXML_BASE_PATH = "/org/example/jfxboilerplate/view/";
    public static final String FONT_BASE_PATH = "/org/example/jfxboilerplate/fonts/";
}
