package org.example.jfxboilerplate.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseUtil {

    private static final String URL = "jdbc:mariadb://ipv4.kosmidis.me:33066/gkoutsogiannopoulos23b_db1";
    private static final String USER = "gkoutsogiannopoulos23b";
    private static final String PASSWORD = "8a79d7ca";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
