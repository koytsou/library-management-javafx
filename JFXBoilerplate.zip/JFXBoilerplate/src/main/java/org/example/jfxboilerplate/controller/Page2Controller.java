package org.example.jfxboilerplate.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import org.example.jfxboilerplate.dao.BorrowerDao;
import org.example.jfxboilerplate.model.Borrower;

public class Page2Controller {
    @FXML private Label deleteMessageLabel;
    @FXML private TableView<Borrower> borrowersTable;
    @FXML private TableColumn<Borrower, Integer> borrowerIdColumn;
    @FXML private TableColumn<Borrower, String> firstNameColumn;
    @FXML private TableColumn<Borrower, String> lastNameColumn;
    @FXML private TableColumn<Borrower, String> emailColumn;
    @FXML private TableColumn<Borrower, String> phoneColumn;
    @FXML private TableColumn<Borrower, String> addressColumn;
    @FXML private Button deleteButton;
    @FXML private Button editButton;

    @FXML private VBox addBorrowerForm;
    @FXML private Button addBorrowerButton;
    @FXML private TextField firstNameField, lastNameField, emailField, phoneField, addressField;
    @FXML private Label messageLabel;

    private final BorrowerDao borrowerDao = new BorrowerDao();
    private ObservableList<Borrower> borrowersData = FXCollections.observableArrayList();
    private Borrower selectedForEdit = null;

    public void initialize() {
        borrowerIdColumn.setCellValueFactory(cellData -> cellData.getValue().borrowerIdProperty().asObject());
        firstNameColumn.setCellValueFactory(cellData -> cellData.getValue().firstNameProperty());
        lastNameColumn.setCellValueFactory(cellData -> cellData.getValue().lastNameProperty());
        emailColumn.setCellValueFactory(cellData -> cellData.getValue().emailProperty());
        phoneColumn.setCellValueFactory(cellData -> cellData.getValue().phoneProperty());
        addressColumn.setCellValueFactory(cellData -> cellData.getValue().addressProperty());

        fetchBorrowersFromDatabase();

        addBorrowerButton.setOnAction(e -> handleAddBorrower());
        deleteButton.setOnAction(e -> handleDelete());
        editButton.setOnAction(e -> handleEditBorrower());
    }

    private void fetchBorrowersFromDatabase() {
        borrowersData.clear();
        borrowersData.addAll(borrowerDao.getAllBorrowers());
        borrowersTable.setItems(borrowersData);
    }

    @FXML
    private void handleAddBorrower() {
        borrowersTable.setVisible(false);
        addBorrowerForm.setVisible(true);
        addBorrowerButton.setVisible(false);
        deleteButton.setVisible(false);
        editButton.setVisible(false);
        deleteMessageLabel.setVisible(false);
        selectedForEdit = null;
    }

    @FXML
    private void handleSubmitBorrower() {
        String firstName = firstNameField.getText();
        String lastName = lastNameField.getText();
        String email = emailField.getText();
        String phone = phoneField.getText();
        String address = addressField.getText();

        if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty() || phone.isEmpty() || address.isEmpty()) {
            deleteMessageLabel.setText("Please fill in all fields.");
            deleteMessageLabel.setVisible(true);
            return;
        }

        if (!email.matches("^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$")) {
            deleteMessageLabel.setText("Invalid email format.");
            deleteMessageLabel.setVisible(true);
            return;
        }

        if (selectedForEdit == null) {
            Borrower newBorrower = new Borrower(0, firstName, lastName, email, phone, address);
            borrowerDao.insertBorrower(newBorrower);
            deleteMessageLabel.setText("User Added Successfully!");
        } else {
            selectedForEdit.firstNameProperty().set(firstName);
            selectedForEdit.lastNameProperty().set(lastName);
            selectedForEdit.emailProperty().set(email);
            selectedForEdit.phoneProperty().set(phone);
            selectedForEdit.addressProperty().set(address);
            borrowerDao.updateBorrower(selectedForEdit);
            deleteMessageLabel.setText("User Updated Successfully!");
        }

        deleteMessageLabel.setVisible(true);
        fetchBorrowersFromDatabase();
        resetForm();
        handleBack();
    }

    @FXML
    private void handleEditBorrower() {
        selectedForEdit = borrowersTable.getSelectionModel().getSelectedItem();
        if (selectedForEdit == null) {
            deleteMessageLabel.setText("No user selected for editing.");
            deleteMessageLabel.setVisible(true);
            return;
        }

        firstNameField.setText(selectedForEdit.firstNameProperty().get());
        lastNameField.setText(selectedForEdit.lastNameProperty().get());
        emailField.setText(selectedForEdit.emailProperty().get());
        phoneField.setText(selectedForEdit.phoneProperty().get());
        addressField.setText(selectedForEdit.addressProperty().get());

        borrowersTable.setVisible(false);
        addBorrowerForm.setVisible(true);
        addBorrowerButton.setVisible(false);
        deleteButton.setVisible(false);
        editButton.setVisible(false);
        deleteMessageLabel.setVisible(false);
    }

    @FXML
    private void handleBack() {
        borrowersTable.setVisible(true);
        addBorrowerForm.setVisible(false);
        addBorrowerButton.setVisible(true);
        deleteButton.setVisible(true);
        editButton.setVisible(true);
        selectedForEdit = null;
    }

    @FXML
    private void handleDelete() {
        Borrower selected = borrowersTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            deleteMessageLabel.setText("No user selected for deletion.");
            deleteMessageLabel.setVisible(true);
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Επιβεβαίωση Διαγραφής");
        alert.setHeaderText(null);
        alert.setContentText("Είσαι σίγουρος ότι θέλεις να διαγράψεις τον χρήστη;");
        if (alert.showAndWait().orElse(ButtonType.CANCEL) != ButtonType.OK) return;

        borrowerDao.deleteBorrower(selected.borrowerIdProperty().get());
        borrowersData.remove(selected);
        deleteMessageLabel.setText("User deleted successfully.");
        deleteMessageLabel.setVisible(true);
    }

    private void resetForm() {
        firstNameField.clear();
        lastNameField.clear();
        emailField.clear();
        phoneField.clear();
        addressField.clear();
    }
}