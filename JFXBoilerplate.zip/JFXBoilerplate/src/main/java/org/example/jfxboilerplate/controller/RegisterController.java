package org.example.jfxboilerplate.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import org.example.jfxboilerplate.App;
import org.example.jfxboilerplate.common.Utils;
import org.example.jfxboilerplate.util.DatabaseUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class RegisterController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private TextField fullNameField;

    @FXML
    private void handleRegister() {
        String username = usernameField.getText();
        String password = passwordField.getText();
        String fullName = fullNameField.getText();

        if (username.isBlank() || password.isBlank() || fullName.isBlank()) {
            showAlert(Alert.AlertType.WARNING, "Προσοχή", "Συμπληρώστε όλα τα πεδία.");
            return;
        }

        try (Connection conn = DatabaseUtil.getConnection()) {
            String checkSql = "SELECT id FROM staff_accounts WHERE username = ?";
            try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
                checkStmt.setString(1, username);
                ResultSet rs = checkStmt.executeQuery();
                if (rs.next()) {
                    showAlert(Alert.AlertType.ERROR, "Σφάλμα", "Το username υπάρχει ήδη.");
                    return;
                }
            }

            String insertSql = "INSERT INTO staff_accounts (username, password, full_name, created_at) " +
                    "VALUES (?, ?, ?, CURRENT_TIMESTAMP)";

            try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                String hashedPassword = Utils.hashString(password);
                insertStmt.setString(1, username);
                insertStmt.setString(2, hashedPassword);
                insertStmt.setString(3, fullName);
                insertStmt.executeUpdate();
            }

            showAlert(Alert.AlertType.INFORMATION, "Επιτυχία", "Ο λογαριασμός δημιουργήθηκε επιτυχώς.");
            BaseController.loadScene("LoginPage");

        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Σφάλμα", "Αποτυχία δημιουργίας λογαριασμού.");
        }
    }

    @FXML
    private void handleGoToLogin() {
        App.loadScene("LoginPage", 966, 673);
    }

    private void showAlert(Alert.AlertType type, String title, String msg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}