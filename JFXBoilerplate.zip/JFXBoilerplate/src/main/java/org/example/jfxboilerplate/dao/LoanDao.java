package org.example.jfxboilerplate.dao;

import org.example.jfxboilerplate.util.DatabaseUtil;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class LoanDao {

    public static class BorrowerItem {
        public int id;
        public String name;
        public Double score;

        public BorrowerItem(int id, String name, Double score) {
            this.id = id;
            this.name = name;
            this.score = score;
        }

        @Override
        public String toString() {
            return score != null
                    ? name + " (Score: " + String.format("%.0f", score) + "%)"
                    : name + " (No Score)";
        }
    }


    public List<BorrowerItem> getAllBorrowersWithScore() {
        List<BorrowerItem> borrowers = new ArrayList<>();
        String sql = """
            SELECT b.borrower_id, b.first_name, b.last_name, r.score
            FROM borrowers b
            LEFT JOIN borrower_reputation r ON b.borrower_id = r.borrower_id
            ORDER BY b.first_name, b.last_name
        """;

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("borrower_id");
                String name = rs.getString("first_name") + " " + rs.getString("last_name");
                Double score = rs.getObject("score") != null ? rs.getDouble("score") : null;
                borrowers.add(new BorrowerItem(id, name, score));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return borrowers;
    }

    public List<String> getAvailableBooks() {
        List<String> books = new ArrayList<>();
        String sql = "SELECT book_id, title FROM books WHERE copies_available > 0";

        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                books.add(rs.getInt("book_id") + " - " + rs.getString("title"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return books;
    }
    public boolean hasActiveLoans(int borrowerId) {
        String sql = "SELECT COUNT(*) FROM loans WHERE borrower_id = ? AND return_date IS NULL";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, borrowerId);
            ResultSet rs = stmt.executeQuery();
            return rs.next() && rs.getInt(1) > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    public void submitLoan(int borrowerId, int bookId, LocalDate loanDate, LocalDate dueDate) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            // insert into loans
            String sql = "INSERT INTO loans (book_id, borrower_id, loan_date, due_date) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, bookId);
                stmt.setInt(2, borrowerId);
                stmt.setDate(3, Date.valueOf(loanDate));
                stmt.setDate(4, Date.valueOf(dueDate));
                stmt.executeUpdate();
            }

            // update availability
            try (PreparedStatement stmt = conn.prepareStatement(
                    "UPDATE books SET copies_available = copies_available - 1 WHERE book_id = ?")) {
                stmt.setInt(1, bookId);
                stmt.executeUpdate();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
