module org.example.jfxboilerplate {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires net.synedra.validatorfx;
    requires org.kordamp.ikonli.javafx;
    requires org.kordamp.bootstrapfx.core;
    requires bcrypt;
    requires org.jetbrains.annotations;
    requires com.google.gson;
    requires com.fasterxml.jackson.databind;
    requires java.desktop;
    requires java.sql;


    // Άνοιγμα των πακέτων για πρόσβαση από JavaFX και reflection
    opens org.example.jfxboilerplate.model to javafx.base, javafx.fxml;
    opens org.example.jfxboilerplate.controller to javafx.fxml;

    // Εξαγωγή των πακέτων αν απαιτείται από άλλες κλάσεις
    exports org.example.jfxboilerplate;
    exports org.example.jfxboilerplate.model;
    exports org.example.jfxboilerplate.controller;
}
